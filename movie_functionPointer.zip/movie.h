
void* mv_genMvInfo(char* name, float score, int runTime, char* country);
int mv_printAll(void* obj, void* arg);
int mv_printCountry(void* obj, void* arg);
int mv_printScore(void* obj, void* arg);
int mv_printRunTime(void* obj, void* arg);
